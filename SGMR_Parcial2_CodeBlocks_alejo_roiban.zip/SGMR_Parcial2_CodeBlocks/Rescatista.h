#ifndef RESCATISTA_H
#define RESCATISTA_H

#include "Personal.h"

/*
CRC - Clase Rescatista
Responsabilidades:
- Representar un rescatista registrado en el SGMR.
- Ejecutar la accion operativa propia de su rol.
Colaboraciones:
- Personal, Mision.
*/
class Rescatista : public Personal
{
public:
    Rescatista(const string& pId, const string& pNombre,
               const string& pEspecialidad);
    ~Rescatista() override;

    const char* getTipo() const override;
    void mostrarInformacion() const override;
    void ejecutarAccion() const override;
};

#endif
