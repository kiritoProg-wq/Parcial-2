# SGMR - Parcial 2 FPOO

Sistema de Gestion de Misiones de Rescate desarrollado en C++.

## Abrir en CodeBlocks
1. Extraer la carpeta completa.
2. Abrir `SGMR_Parcial2.cbp`.
3. Ejecutar **Build -> Rebuild** y luego **Build -> Run**.

## Compilar desde terminal
```bash
g++ -std=c++11 -Wall -Wextra *.cpp -o SGMR_Parcial2
./SGMR_Parcial2
```

## Requisitos implementados
- HU01: registro dinamico de ambulancias, helicopteros, medicos y rescatistas.
- HU02: asignacion de recursos heterogeneos mediante `Recurso*`.
- HU03: ejecucion polimorfica con funciones virtuales.
- HU04: `main.cpp` solo crea `Controlador` e invoca `iniciar()`.
- HU05: 2 misiones, 2 ambulancias, 1 helicoptero, 2 medicos y 2 rescatistas precargados.
- HT01: arreglos dinamicos manuales; no se usa `std::vector`.
- HT02: destructores, `delete` y `delete[]` sin doble liberacion.
- HT03: objetos complejos enviados por referencia o puntero.
