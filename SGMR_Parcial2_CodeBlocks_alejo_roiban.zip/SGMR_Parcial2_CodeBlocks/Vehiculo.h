#ifndef VEHICULO_H
#define VEHICULO_H

#include "Recurso.h"

/*
CRC - Clase Vehiculo
Responsabilidades:
- Agrupar los datos comunes de los recursos vehiculares.
- Conservar placa y capacidad.
Colaboraciones:
- Recurso, Ambulancia, Helicoptero.
*/
class Vehiculo : public Recurso
{
protected:
    string placa;
    int capacidad;

    void mostrarDatosVehiculo() const;

public:
    Vehiculo(const string& pId, const string& pNombre,
             const string& pPlaca, int pCapacidad);
    virtual ~Vehiculo();

    const string& getPlaca() const;
    int getCapacidad() const;
};

#endif
